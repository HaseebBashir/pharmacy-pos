# Pharmacy POS (Android) - version 0.1

Offline-first pharmacy billing and stock app (Kotlin, Jetpack Compose, Room).

Included: medicines, batches and expiry, FEFO selling, expired/blocked batch blocking, camera barcode scan,
POS with discount and wholesale rates, cash / partial / udhaar sales with credit limit, customer ledger and payment
collection, whole-bill return, bill history, 58/80 mm Bluetooth receipt print and reprint, share bill by WhatsApp/SMS,
expiry and low-stock alerts, CSV share of the medicine list.

Not included yet (planned later): backend and multi-phone sync, users and roles, shift close, purchase orders and
suppliers, accounting reports, controlled-drug register, prescriptions, salary, web panel.

IMPORTANT: this code has not been compiled or run by its author. The first GitHub build may show errors; send them
back and they will be fixed.
