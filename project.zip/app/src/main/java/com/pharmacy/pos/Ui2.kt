package com.pharmacy.pos

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.launch

@Composable
fun MedsUi(c: Ctrl, back: () -> Unit, go: (Nav) -> Unit) {
    var q by remember { mutableStateOf("") }
    val list by remember(q) { c.dao.searchMedicines(q.trim()) }.collectAsState(emptyList())
    val stockRows by remember { c.dao.stockTotals(Fmt.today()) }.collectAsState(emptyList())
    val stock = stockRows.associate { it.medicineId to it.total }
    LazyColumn(Modifier.fillMaxWidth()) {
        item { Header("Medicines aur Stock", back) }
        item {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("Search (naam / brand / salt / barcode)", q, { q = it })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { go(Nav.MedEdit(0L)) }) { Text("+ Nayi Medicine") }
                    OutlinedButton(onClick = {
                        val sb = StringBuilder("name,brand,salt,barcode,rack,pack_size,retail_pack_price,wholesale_pack_price,stock_units\n")
                        for (m in list) {
                            sb.append(m.name.replace(",", " ")).append(',')
                                .append(m.brand.replace(",", " ")).append(',')
                                .append(m.salt.replace(",", " ")).append(',')
                                .append(m.barcode).append(',')
                                .append(m.rack.replace(",", " ")).append(',')
                                .append(m.packSize).append(',')
                                .append(Fmt.num(m.retailPrice)).append(',')
                                .append(Fmt.num(m.wholesalePrice)).append(',')
                                .append(stock[m.id] ?: 0).append('\n')
                        }
                        c.share(sb.toString())
                    }) { Text("CSV bhejein") }
                }
            }
        }
        items(list) { m ->
            val st = stock[m.id] ?: 0
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).clickable { go(Nav.MedEdit(m.id)) }) {
                Column(Modifier.padding(10.dp)) {
                    Text(m.name + if (m.brand.isNotBlank()) " (" + m.brand + ")" else "", fontWeight = FontWeight.Bold)
                    if (m.salt.isNotBlank()) Text(m.salt)
                    Text(
                        "Stock: " + Fmt.qtyText(st, m.packSize) + "  |  Retail pack: " + Fmt.rs(m.retailPrice) +
                            (if (m.rack.isNotBlank()) "  |  Rack " + m.rack else "")
                    )
                    if (m.reorderLevel > 0 && st <= m.reorderLevel) Text("Kam stock!", color = Color(0xFFB3261E))
                }
            }
        }
    }
}

@Composable
fun MedEditUi(c: Ctrl, id: Long, back: () -> Unit, go: (Nav) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var salt by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var rack by remember { mutableStateOf("") }
    var pack by remember { mutableStateOf("1") }
    var retail by remember { mutableStateOf("") }
    var wholesale by remember { mutableStateOf("") }
    var reorder by remember { mutableStateOf("") }
    val batches by remember(id) { c.dao.batchesFor(id) }.collectAsState(emptyList())
    var writeOff by remember { mutableStateOf<Batch?>(null) }

    LaunchedEffect(id) {
        if (id != 0L) {
            val m = c.dao.medicine(id)
            if (m != null) {
                name = m.name
                brand = m.brand
                salt = m.salt
                barcode = m.barcode
                rack = m.rack
                pack = m.packSize.toString()
                retail = Fmt.num(m.retailPrice)
                wholesale = if (m.wholesalePrice > 0) Fmt.num(m.wholesalePrice) else ""
                reorder = if (m.reorderLevel > 0) m.reorderLevel.toString() else ""
            }
        }
    }

    val packN = pack.toIntOrNull() ?: 1
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Header(if (id == 0L) "Nayi Medicine" else "Medicine", back)
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Naam *", name, { name = it })
            Field("Brand / company", brand, { brand = it })
            Field("Salt / formula", salt, { salt = it })
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("Barcode", barcode, { barcode = it }, Modifier.weight(1f))
                Button(onClick = {
                    try {
                        GmsBarcodeScanning.getClient(ctx).startScan()
                            .addOnSuccessListener { b -> barcode = b.rawValue ?: barcode }
                            .addOnFailureListener { e -> c.toast("Scan nahi hua: " + (e.message ?: "")) }
                    } catch (e: Exception) {
                        c.toast("Scanner nahi chala")
                    }
                }) { Text("Scan") }
            }
            Field("Rack / shelf", rack, { rack = it })
            Field("Pack size (ek pack mein kitni tablet/piece) *", pack, { pack = it }, number = true)
            Field("Retail price per pack (Rs) *", retail, { retail = it }, number = true)
            Field("Wholesale price per pack (Rs)", wholesale, { wholesale = it }, number = true)
            Field("Reorder level (loose units)", reorder, { reorder = it }, number = true)
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                val ps = pack.toIntOrNull() ?: 0
                val rp = Fmt.parseMoney(retail)
                val wp = if (wholesale.isBlank()) 0L else (Fmt.parseMoney(wholesale) ?: -1L)
                if (name.isBlank() || ps < 1 || rp == null || wp < 0) {
                    c.toast("Naam, pack size aur retail price sahi likhein")
                } else {
                    c.scope.launch {
                        val dup = if (barcode.isBlank()) null else c.dao.medicineByBarcode(barcode.trim())
                        if (dup != null && dup.id != id) {
                            c.toast("Ye barcode " + dup.name + " ka hai")
                        } else {
                            val m = Medicine(
                                id = id, name = name.trim(), brand = brand.trim(), salt = salt.trim(),
                                barcode = barcode.trim(), rack = rack.trim(), packSize = ps,
                                retailPrice = rp, wholesalePrice = wp, reorderLevel = reorder.toIntOrNull() ?: 0
                            )
                            if (id == 0L) c.dao.insertMedicine(m) else c.dao.updateMedicine(m)
                            c.toast("Save ho gaya")
                            back()
                        }
                    }
                }
            }) { Text("Save") }

            if (id != 0L) {
                HorizontalDivider()
                Text("Batches", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Button(modifier = Modifier.fillMaxWidth(), onClick = { go(Nav.Receive(id)) }) { Text("+ Stock receive (nayi batch)") }
                for (b in batches) {
                    val expired = b.expiryDay < Fmt.today()
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            Text("Batch " + b.batchNo + "  |  Exp " + Fmt.expiry(b.expiryDay), fontWeight = FontWeight.Bold)
                            Text("Qty: " + Fmt.qtyText(b.qty, packN) + "  |  Cost/pack: " + Fmt.rs(b.costPerPack))
                            if (expired) Text("EXPIRED - bik nahi sakti", color = Color(0xFFB3261E))
                            if (b.blocked) Text("BLOCKED (recall/quarantine)", color = Color(0xFFB3261E))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { c.scope.launch { c.repo.setBlocked(b.id, !b.blocked) } }) {
                                    Text(if (b.blocked) "Unblock" else "Block")
                                }
                                if (b.qty > 0) {
                                    OutlinedButton(onClick = { writeOff = b }) { Text("Write-off") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    val wo = writeOff
    if (wo != null) {
        AlertDialog(
            onDismissRequest = { writeOff = null },
            title = { Text("Batch " + wo.batchNo + " write-off?") },
            text = { Text("Is batch ka poora stock zero ho jayega (record rahega).") },
            confirmButton = {
                TextButton(onClick = {
                    writeOff = null
                    c.scope.launch { c.repo.writeOff(wo.id) }
                }) { Text("Haan") }
            },
            dismissButton = { TextButton(onClick = { writeOff = null }) { Text("Nahi") } }
        )
    }
}

@Composable
fun ReceiveUi(c: Ctrl, medId: Long, back: () -> Unit) {
    var med by remember { mutableStateOf<Medicine?>(null) }
    var batchNo by remember { mutableStateOf("") }
    var expiry by remember { mutableStateOf("") }
    var packs by remember { mutableStateOf("") }
    var loose by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    LaunchedEffect(medId) { med = c.dao.medicine(medId) }
    val m = med
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Header("Stock receive", back)
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (m != null) m.name + " (pack = " + m.packSize + ")" else "...", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Field("Batch number *", batchNo, { batchNo = it })
            Field("Expiry (MM/YYYY) *", expiry, { expiry = it })
            Field("Packs", packs, { packs = it }, number = true)
            Field("Loose units (extra)", loose, { loose = it }, number = true)
            Field("Purchase cost per pack (Rs)", cost, { cost = it }, number = true)
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                val ex = Fmt.parseExpiry(expiry)
                val qty = (packs.toIntOrNull() ?: 0) * (m?.packSize ?: 1) + (loose.toIntOrNull() ?: 0)
                if (ex == null) {
                    c.toast("Expiry MM/YYYY mein likhein, jaise 08/2027")
                } else {
                    c.scope.launch {
                        try {
                            c.repo.receiveStock(medId, batchNo, ex, qty, Fmt.parseMoney(cost) ?: 0L)
                            c.toast("Stock add ho gaya")
                            back()
                        } catch (e: AppError) {
                            c.toast(e.message ?: "Error")
                        }
                    }
                }
            }) { Text("Stock add karein") }
        }
    }
}

@Composable
fun CustomersUi(c: Ctrl, back: () -> Unit, go: (Nav) -> Unit) {
    val list by remember { c.dao.customers() }.collectAsState(emptyList())
    val balRows by remember { c.dao.balances() }.collectAsState(emptyList())
    val bal = balRows.associate { it.customerId to it.total }
    var adding by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var limit by remember { mutableStateOf("") }
    var wh by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxWidth()) {
        item { Header("Customers aur Udhaar", back) }
        item {
            Button(modifier = Modifier.padding(12.dp), onClick = { adding = true }) { Text("+ Naya Customer") }
        }
        items(list) { cu ->
            val b = bal[cu.id] ?: 0L
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).clickable { go(Nav.CustomerDetail(cu.id)) }) {
                Column(Modifier.padding(10.dp)) {
                    Text(cu.name + if (cu.wholesale) " (wholesale)" else "", fontWeight = FontWeight.Bold)
                    Text(cu.phone)
                    Text("Baqaya: " + Fmt.rs(b) + "  |  Limit: " + Fmt.rs(cu.creditLimit), color = if (b > 0) Color(0xFFB3261E) else Color.Unspecified)
                }
            }
        }
    }
    if (adding) {
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("Naya customer") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Field("Naam *", name, { name = it })
                    Field("Phone", phone, { phone = it })
                    Field("Credit limit (Rs)", limit, { limit = it }, number = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Wholesale customer", Modifier.weight(1f))
                        Switch(checked = wh, onCheckedChange = { wh = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isBlank()) {
                        c.toast("Naam likhein")
                    } else {
                        val lim = Fmt.parseMoney(limit) ?: 0L
                        c.scope.launch {
                            c.dao.insertCustomer(Customer(name = name.trim(), phone = phone.trim(), wholesale = wh, creditLimit = lim))
                        }
                        name = ""
                        phone = ""
                        limit = ""
                        wh = false
                        adding = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun CustomerDetailUi(c: Ctrl, id: Long, back: () -> Unit) {
    var cust by remember { mutableStateOf<Customer?>(null) }
    var reload by remember { mutableStateOf(0) }
    val ledger by remember(id) { c.dao.ledgerFor(id) }.collectAsState(emptyList())
    var payDialog by remember { mutableStateOf(false) }
    var limitDialog by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    LaunchedEffect(id, reload) { cust = c.dao.customer(id) }
    val cu = cust
    val balance = ledger.sumOf { it.amount }
    LazyColumn(Modifier.fillMaxWidth()) {
        item { Header(cu?.name ?: "Customer", back) }
        item {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Baqaya: " + Fmt.rs(balance), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                if (cu != null) Text("Credit limit: " + Fmt.rs(cu.creditLimit) + (if (cu.phone.isNotBlank()) "  |  " + cu.phone else ""))
                Button(modifier = Modifier.fillMaxWidth(), onClick = { amount = ""; payDialog = true }) { Text("Payment wasool karein") }
                OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { amount = ""; limitDialog = true }) { Text("Credit limit badlein") }
                OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                    c.share(
                        "Assalam o Alaikum " + (cu?.name ?: "") + ", aap ka " + c.settings.shopName +
                            " ka baqaya " + Fmt.rs(balance) + " hai. Meherbani karke ada kar dein. Shukriya."
                    )
                }) { Text("Baqaya reminder (WhatsApp / SMS)") }
                HorizontalDivider()
                Text("Ledger", fontWeight = FontWeight.Bold)
            }
        }
        items(ledger) { e ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                Column(Modifier.weight(1f)) {
                    Text(e.type + "  " + e.ref, fontSize = 13.sp)
                    Text(Fmt.dateTime(e.time), fontSize = 11.sp)
                }
                Text(Fmt.rs(e.amount), color = if (e.amount > 0) Color(0xFFB3261E) else Color(0xFF0F6B57))
            }
        }
    }
    if (payDialog) {
        AlertDialog(
            onDismissRequest = { payDialog = false },
            title = { Text("Payment wasool") },
            text = { Field("Amount (Rs)", amount, { amount = it }, number = true) },
            confirmButton = {
                TextButton(onClick = {
                    val a = Fmt.parseMoney(amount)
                    if (a == null || a <= 0) {
                        c.toast("Amount sahi likhein")
                    } else {
                        c.scope.launch {
                            try {
                                c.repo.collectPayment(id, a)
                            } catch (e: AppError) {
                                c.toast(e.message ?: "Error")
                            }
                        }
                        payDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { payDialog = false }) { Text("Cancel") } }
        )
    }
    if (limitDialog && cu != null) {
        AlertDialog(
            onDismissRequest = { limitDialog = false },
            title = { Text("Credit limit") },
            text = { Field("Limit (Rs)", amount, { amount = it }, number = true) },
            confirmButton = {
                TextButton(onClick = {
                    val a = Fmt.parseMoney(amount)
                    if (a == null) {
                        c.toast("Amount sahi likhein")
                    } else {
                        c.scope.launch {
                            c.dao.updateCustomer(cu.copy(creditLimit = a))
                            reload++
                        }
                        limitDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { limitDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
fun BillsUi(c: Ctrl, back: () -> Unit, go: (Nav) -> Unit) {
    val sales by remember { c.dao.recentSales() }.collectAsState(emptyList())
    LazyColumn(Modifier.fillMaxWidth()) {
        item { Header("Purane Bills", back) }
        items(sales) { s ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).clickable { go(Nav.Bill(s.id, false)) }) {
                Column(Modifier.padding(10.dp)) {
                    Text(s.invoiceNo, fontWeight = FontWeight.Bold)
                    Text(Fmt.dateTime(s.time) + (if (s.customerName.isNotBlank()) "  |  " + s.customerName else ""))
                    Text(
                        Fmt.rs(s.total) + (if (s.credit > 0) "  (udhaar " + Fmt.rs(s.credit) + ")" else "") +
                            (if (s.status != "DONE") "  [WAPAS]" else ""),
                        color = if (s.status != "DONE") Color(0xFFB3261E) else Color.Unspecified
                    )
                }
            }
        }
    }
}

@Composable
fun AlertsUi(c: Ctrl, back: () -> Unit) {
    val today = Fmt.today()
    val batches by remember { c.dao.expiringBatches(today + 90) }.collectAsState(emptyList())
    val meds by remember { c.dao.allMedicines() }.collectAsState(emptyList())
    val stockRows by remember { c.dao.stockTotals(today) }.collectAsState(emptyList())
    val stock = stockRows.associate { it.medicineId to it.total }
    val byId = meds.associateBy { it.id }
    val expired = batches.filter { it.expiryDay < today }
    val near = batches.filter { it.expiryDay >= today }
    val low = meds.filter { it.reorderLevel > 0 && (stock[it.id] ?: 0) <= it.reorderLevel }
    LazyColumn(Modifier.fillMaxWidth()) {
        item { Header("Alerts", back) }
        item { Text("Expire ho chuki batches (" + expired.size + ")", fontWeight = FontWeight.Bold, color = Color(0xFFB3261E), modifier = Modifier.padding(12.dp)) }
        items(expired) { b ->
            val m = byId[b.medicineId]
            Text((m?.name ?: "?") + "  |  Batch " + b.batchNo + "  |  " + Fmt.expiry(b.expiryDay) + "  |  qty " + Fmt.qtyText(b.qty, m?.packSize ?: 1), Modifier.padding(horizontal = 12.dp, vertical = 3.dp))
        }
        item { Text("90 din mein expire (" + near.size + ")", fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp)) }
        items(near) { b ->
            val m = byId[b.medicineId]
            Text((m?.name ?: "?") + "  |  Batch " + b.batchNo + "  |  " + Fmt.expiry(b.expiryDay) + "  |  qty " + Fmt.qtyText(b.qty, m?.packSize ?: 1), Modifier.padding(horizontal = 12.dp, vertical = 3.dp))
        }
        item { Text("Kam stock (" + low.size + ")", fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp)) }
        items(low) { m ->
            Text(m.name + "  |  stock " + Fmt.qtyText(stock[m.id] ?: 0, m.packSize) + "  |  reorder " + m.reorderLevel, Modifier.padding(horizontal = 12.dp, vertical = 3.dp))
        }
    }
}

@Composable
fun PrefsUi(c: Ctrl, back: () -> Unit) {
    val ctx = LocalContext.current
    val s0 = c.settings
    var shop by remember { mutableStateOf(s0.shopName) }
    var phone by remember { mutableStateOf(s0.shopPhone) }
    var device by remember { mutableStateOf(s0.deviceCode) }
    var paper58 by remember { mutableStateOf(s0.paper58) }
    var pMac by remember { mutableStateOf(s0.printerMac) }
    var pName by remember { mutableStateOf(s0.printerName) }
    var showPrinters by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) showPrinters = true else c.toast("Bluetooth ki ijazat zaroori hai")
    }

    fun current() = ShopSettings(shop.trim().ifBlank { "My Pharmacy" }, phone.trim(), device.trim().ifBlank { "POS-01" }, pMac, pName, paper58)

    Column(Modifier.verticalScroll(rememberScrollState())) {
        Header("Settings aur Printer", back)
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Field("Pharmacy ka naam", shop, { shop = it })
            Field("Phone (receipt par)", phone, { phone = it })
            Field("Device code (jaise POS-01, har phone ka alag)", device, { device = it })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (paper58) "Paper: 58 mm" else "Paper: 80 mm", Modifier.weight(1f))
                Switch(checked = paper58, onCheckedChange = { paper58 = it })
            }
            Text("Printer: " + (if (pMac.isBlank()) "chuna nahi" else pName + " (" + pMac + ")"))
            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                if (Build.VERSION.SDK_INT >= 31 &&
                    ctx.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) {
                    permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
                } else {
                    showPrinters = true
                }
            }) { Text("Printer chunein (pehle phone mein pair karein)") }
            OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                if (pMac.isBlank()) {
                    c.toast("Pehle printer chunein")
                } else {
                    c.scope.launch {
                        val err = BtPrinter.print(ctx, pMac, "Test print OK\n" + shop + "\n\n")
                        c.toast(err ?: "Test print ho gaya")
                    }
                }
            }) { Text("Test print") }
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                c.saveSettings(current())
                c.toast("Settings save ho gayi")
                back()
            }) { Text("Save") }
        }
    }
    if (showPrinters) {
        val devices = BtPrinter.bonded(ctx)
        AlertDialog(
            onDismissRequest = { showPrinters = false },
            title = { Text("Paired printers") },
            text = {
                if (devices.isEmpty()) {
                    Text("Koi paired device nahi mila. Phone ki Bluetooth settings mein printer pair karein.")
                } else {
                    LazyColumn {
                        items(devices) { d ->
                            val nm = try {
                                d.name ?: d.address
                            } catch (e: SecurityException) {
                                d.address
                            }
                            Text(
                                nm + "\n" + d.address,
                                Modifier.fillMaxWidth().clickable {
                                    pMac = d.address
                                    pName = nm
                                    showPrinters = false
                                }.padding(12.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPrinters = false }) { Text("Band") } }
        )
    }
}
