package com.pharmacy.pos

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun HomeUi(c: Ctrl, go: (Nav) -> Unit) {
    val dayStart = remember {
        LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }
    val total by remember { c.dao.salesTotalSince(dayStart) }.collectAsState(0L)
    val count by remember { c.dao.salesCountSince(dayStart) }.collectAsState(0)
    val expiring by remember { c.dao.expiringBatches(Fmt.today() + 90) }.collectAsState(emptyList())
    Column {
        Header(c.settings.shopName, null)
        Column(
            Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Aaj ki sale (" + c.settings.deviceCode + ")")
                    Text(Fmt.rs(total), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("$count bills")
                }
            }
            Big("Naya Bill (POS)") { go(Nav.Pos) }
            Big("Medicines aur Stock") { go(Nav.Meds) }
            Big("Customers aur Udhaar") { go(Nav.Customers) }
            Big("Purane Bills") { go(Nav.Bills) }
            Big("Alerts (expiry / kam stock) " + (if (expiring.isNotEmpty()) "[" + expiring.size + "]" else "")) { go(Nav.Alerts) }
            Big("Settings aur Printer") { go(Nav.Prefs) }
        }
    }
}

@Composable
fun PosUi(c: Ctrl, back: () -> Unit, go: (Nav) -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val results by remember(q) { c.dao.searchMedicines(q.trim()) }.collectAsState(emptyList())
    val stockRows by remember { c.dao.stockTotals(Fmt.today()) }.collectAsState(emptyList())
    val stock = stockRows.associate { it.medicineId to it.total }
    val customers by remember { c.dao.customers() }.collectAsState(emptyList())
    var discount by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var pick by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    fun add(m: Medicine, units: Int) {
        val avail = stock[m.id] ?: 0
        val idx = c.cart.indexOfFirst { it.medicine.id == m.id }
        val cur = if (idx >= 0) c.cart[idx].qty else 0
        if (cur + units > avail) {
            c.toast(m.name + ": stock sirf " + Fmt.qtyText(avail, m.packSize) + " hai")
            return
        }
        if (idx >= 0) c.cart[idx] = c.cart[idx].copy(qty = cur + units) else c.cart.add(CartLine(m, units))
    }

    fun reduce(m: Medicine, units: Int) {
        val idx = c.cart.indexOfFirst { it.medicine.id == m.id }
        if (idx < 0) return
        val nq = c.cart[idx].qty - units
        if (nq <= 0) c.cart.removeAt(idx) else c.cart[idx] = c.cart[idx].copy(qty = nq)
    }

    fun scan() {
        try {
            GmsBarcodeScanning.getClient(ctx).startScan()
                .addOnSuccessListener { barcode ->
                    val code = barcode.rawValue
                    if (code != null) {
                        c.scope.launch {
                            val m = c.dao.medicineByBarcode(code)
                            if (m == null) c.toast("Barcode nahi mila: $code") else add(m, 1)
                        }
                    }
                }
                .addOnFailureListener { e -> c.toast("Scan nahi hua: " + (e.message ?: "")) }
        } catch (e: Exception) {
            c.toast("Scanner nahi chala: " + (e.message ?: ""))
        }
    }

    val subtotal = c.cart.sumOf { Repo.lineTotal(it.medicine, c.wholesale, it.qty) }
    val discountP = Fmt.parseMoney(discount) ?: 0L
    val total = subtotal - discountP
    val paidP = if (paid.isBlank()) total else (Fmt.parseMoney(paid) ?: -1L)
    val credit = if (paidP >= 0) maxOf(total - paidP, 0L) else 0L

    LazyColumn(Modifier.fillMaxWidth()) {
        item { Header("Naya Bill", back) }
        item {
            Row(
                Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Field("Medicine search (naam / salt / barcode)", q, { q = it }, Modifier.weight(1f))
                Button(onClick = { scan() }) { Text("Scan") }
            }
        }
        if (q.isNotBlank()) {
            items(results.take(8)) { m ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text(m.name + if (m.brand.isNotBlank()) " (" + m.brand + ")" else "", fontWeight = FontWeight.Bold)
                        Text(
                            "Stock: " + Fmt.qtyText(stock[m.id] ?: 0, m.packSize) + "  |  Pack: " +
                                Fmt.rs(if (c.wholesale && m.wholesalePrice > 0) m.wholesalePrice else m.retailPrice) +
                                (if (m.salt.isNotBlank()) "  |  " + m.salt else "")
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { add(m, m.packSize) }) { Text("+ Pack") }
                            OutlinedButton(onClick = { add(m, 1) }) { Text("+ 1 loose") }
                        }
                    }
                }
            }
        }
        item {
            Text(
                "Cart (" + c.cart.size + ")",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                modifier = Modifier.padding(12.dp)
            )
        }
        items(c.cart.toList()) { line ->
            val m = line.medicine
            Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)) {
                Column(Modifier.padding(10.dp)) {
                    Text(m.name, fontWeight = FontWeight.Bold)
                    Text(Fmt.qtyText(line.qty, m.packSize) + "  =  " + Fmt.rs(Repo.lineTotal(m, c.wholesale, line.qty)))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        val pad = PaddingValues(horizontal = 4.dp)
                        OutlinedButton(onClick = { reduce(m, m.packSize) }, contentPadding = pad, modifier = Modifier.weight(1f)) { Text("-P") }
                        OutlinedButton(onClick = { reduce(m, 1) }, contentPadding = pad, modifier = Modifier.weight(1f)) { Text("-1") }
                        OutlinedButton(onClick = { add(m, 1) }, contentPadding = pad, modifier = Modifier.weight(1f)) { Text("+1") }
                        OutlinedButton(onClick = { add(m, m.packSize) }, contentPadding = pad, modifier = Modifier.weight(1f)) { Text("+P") }
                        TextButton(onClick = { c.cart.removeAll { it.medicine.id == m.id } }, contentPadding = pad, modifier = Modifier.weight(1f)) { Text("X") }
                    }
                }
            }
        }
        item {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Customer: " + (c.customer?.name ?: "Walk-in"), Modifier.weight(1f))
                    OutlinedButton(onClick = { pick = true }) { Text("Chunein") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Wholesale rate", Modifier.weight(1f))
                    Switch(checked = c.wholesale, onCheckedChange = { c.wholesale = it })
                }
                Field("Discount (Rs)", discount, { discount = it }, number = true)
                Field("Paid (Rs) - khali = poora paid", paid, { paid = it }, number = true)
                Text("Subtotal: " + Fmt.rs(subtotal))
                Text("TOTAL: " + Fmt.rs(total), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                if (credit > 0) {
                    Text("Udhaar: " + Fmt.rs(credit), color = MaterialTheme.colorScheme.secondary)
                }
                Button(
                    enabled = !busy && c.cart.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    onClick = {
                        if (paidP < 0) {
                            c.toast("Paid amount galat hai")
                        } else {
                            busy = true
                            val lines = c.cart.toList()
                            c.scope.launch {
                                try {
                                    val id = c.repo.checkout(lines, c.customer, c.wholesale, discountP, paidP, c.settings.deviceCode)
                                    c.cart.clear()
                                    c.customer = null
                                    c.wholesale = false
                                    discount = ""
                                    paid = ""
                                    go(Nav.Bill(id, true))
                                } catch (e: AppError) {
                                    c.toast(e.message ?: "Error")
                                } catch (e: Exception) {
                                    c.toast("Bill save nahi hua: " + (e.message ?: ""))
                                }
                                busy = false
                            }
                        }
                    }
                ) { Text("Bill Banayein aur Save", fontSize = 17.sp) }
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (pick) {
        AlertDialog(
            onDismissRequest = { pick = false },
            confirmButton = { TextButton(onClick = { pick = false }) { Text("Band") } },
            title = { Text("Customer chunein") },
            text = {
                LazyColumn {
                    item {
                        Text(
                            "Walk-in (koi customer nahi)",
                            Modifier.fillMaxWidth().clickable {
                                c.customer = null
                                c.wholesale = false
                                pick = false
                            }.padding(12.dp)
                        )
                    }
                    items(customers) { cu ->
                        Text(
                            cu.name + (if (cu.phone.isNotBlank()) "  " + cu.phone else ""),
                            Modifier.fillMaxWidth().clickable {
                                c.customer = cu
                                c.wholesale = cu.wholesale
                                pick = false
                            }.padding(12.dp)
                        )
                    }
                }
            }
        )
    }
}

@Composable
fun BillUi(c: Ctrl, id: Long, fresh: Boolean, back: () -> Unit) {
    val ctx = LocalContext.current
    var sale by remember { mutableStateOf<Sale?>(null) }
    var items by remember { mutableStateOf<List<SaleItem>>(emptyList()) }
    var reload by remember { mutableStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(id, reload) {
        sale = c.dao.sale(id)
        items = c.dao.itemsFor(id)
    }
    val s = sale
    Column {
        Header(if (fresh) "Bill save ho gaya" else "Bill", back)
        if (s == null) {
            Text("Loading...", Modifier.padding(16.dp))
        } else {
            val text = Receipt.build(c.settings, s, items)
            Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                Button(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (c.settings.printerMac.isBlank()) {
                            c.toast("Pehle Settings mein printer chunein")
                        } else {
                            c.scope.launch {
                                val err = BtPrinter.print(ctx, c.settings.printerMac, text)
                                c.toast(err ?: "Print ho gayi")
                            }
                        }
                    }
                ) { Text("Receipt Print / Dobara Print") }
                OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { c.share(text) }) { Text("WhatsApp / SMS par bhejein") }
                if (s.status == "DONE") {
                    OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = { confirm = true }) { Text("Poora bill wapas (return)") }
                }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Bill wapas karein?") },
            text = { Text("Stock wapas aayega aur udhaar (agar tha) kam hoga. Ye wapas nahi hota.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    c.scope.launch {
                        try {
                            c.repo.returnSale(id)
                            c.toast("Bill wapas ho gaya")
                            reload++
                        } catch (e: AppError) {
                            c.toast(e.message ?: "Error")
                        }
                    }
                }) { Text("Haan, wapas") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Nahi") } }
        )
    }
}
