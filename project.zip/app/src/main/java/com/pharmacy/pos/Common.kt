package com.pharmacy.pos

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter

object Fmt {
    fun num(p: Long): String {
        val a = Math.abs(p)
        return (if (p < 0) "-" else "") + (a / 100) + "." + (a % 100).toString().padStart(2, '0')
    }

    fun rs(p: Long): String = "Rs " + num(p)

    fun parseMoney(s: String): Long? {
        val t = s.trim()
        if (t.isEmpty()) return null
        val d = t.toBigDecimalOrNull() ?: return null
        if (d.signum() < 0) return null
        return d.movePointRight(2).setScale(0, RoundingMode.HALF_UP).toLong()
    }

    // "MM/YYYY" -> last day of that month (epoch day)
    fun parseExpiry(s: String): Long? {
        val p = s.trim().split("/")
        if (p.size != 2) return null
        val m = p[0].trim().toIntOrNull() ?: return null
        var y = p[1].trim().toIntOrNull() ?: return null
        if (y < 100) y += 2000
        if (m < 1 || m > 12 || y < 2000 || y > 2100) return null
        return YearMonth.of(y, m).atEndOfMonth().toEpochDay()
    }

    private val monthFmt = DateTimeFormatter.ofPattern("MM/yyyy")
    private val dtFmt = DateTimeFormatter.ofPattern("dd/MM/yy HH:mm")

    fun expiry(day: Long): String = LocalDate.ofEpochDay(day).format(monthFmt)

    fun dateTime(ms: Long): String =
        Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(dtFmt)

    fun today(): Long = LocalDate.now().toEpochDay()

    fun qtyText(qty: Int, pack: Int): String {
        if (pack <= 1) return qty.toString()
        val p = qty / pack
        val l = qty % pack
        return if (l == 0) "$p pack" else if (p == 0) "$l loose" else "$p pack + $l"
    }
}

val PharmaColors = lightColorScheme(
    primary = Color(0xFF0F6B57),
    onPrimary = Color.White,
    secondary = Color(0xFF3D6B8E),
    onSecondary = Color.White
)

@Composable
fun Header(title: String, onBack: (() -> Unit)?) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primary)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            TextButton(onClick = onBack) { Text("< Wapas", color = Color.White) }
        }
        Text(
            title,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Composable
fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    number: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = if (number) KeyboardOptions(keyboardType = KeyboardType.Decimal) else KeyboardOptions.Default,
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun Big(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(56.dp)) {
        Text(text, fontSize = 17.sp)
    }
}
