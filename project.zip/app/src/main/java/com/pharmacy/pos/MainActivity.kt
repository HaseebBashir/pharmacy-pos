package com.pharmacy.pos

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel

sealed class Nav {
    object Home : Nav()
    object Pos : Nav()
    object Meds : Nav()
    data class MedEdit(val id: Long) : Nav()
    data class Receive(val medId: Long) : Nav()
    object Customers : Nav()
    data class CustomerDetail(val id: Long) : Nav()
    object Bills : Nav()
    data class Bill(val id: Long, val fresh: Boolean) : Nav()
    object Alerts : Nav()
    object Prefs : Nav()
}

class Ctrl(val act: ComponentActivity) {
    val db = AppDb.get(act)
    val dao = db.dao()
    val repo = Repo(db)
    private val store = SettingsStore(act)
    val scope = MainScope()
    val cart = mutableStateListOf<CartLine>()
    var settings by mutableStateOf(store.load())
    var customer by mutableStateOf<Customer?>(null)
    var wholesale by mutableStateOf(false)

    fun toast(m: String) {
        Toast.makeText(act, m, Toast.LENGTH_LONG).show()
    }

    fun saveSettings(s: ShopSettings) {
        store.save(s)
        settings = s
    }

    fun share(text: String) {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, text)
        act.startActivity(Intent.createChooser(i, "Bhejein"))
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var ctrl: Ctrl

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ctrl = Ctrl(this)
        setContent {
            MaterialTheme(colorScheme = PharmaColors) {
                Surface(Modifier.fillMaxSize()) {
                    App(ctrl)
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) ctrl.scope.cancel()
    }
}

@Composable
fun App(c: Ctrl) {
    var nav by remember { mutableStateOf<Nav>(Nav.Home) }
    val go: (Nav) -> Unit = { nav = it }
    val back: () -> Unit = {
        val n = nav
        nav = when (n) {
            is Nav.MedEdit -> Nav.Meds
            is Nav.Receive -> Nav.MedEdit(n.medId)
            is Nav.CustomerDetail -> Nav.Customers
            is Nav.Bill -> if (n.fresh) Nav.Home else Nav.Bills
            else -> Nav.Home
        }
    }
    BackHandler(enabled = nav != Nav.Home) { back() }
    Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        when (val n = nav) {
            is Nav.Home -> HomeUi(c, go)
            is Nav.Pos -> PosUi(c, back, go)
            is Nav.Meds -> MedsUi(c, back, go)
            is Nav.MedEdit -> MedEditUi(c, n.id, back, go)
            is Nav.Receive -> ReceiveUi(c, n.medId, back)
            is Nav.Customers -> CustomersUi(c, back, go)
            is Nav.CustomerDetail -> CustomerDetailUi(c, n.id, back)
            is Nav.Bills -> BillsUi(c, back, go)
            is Nav.Bill -> BillUi(c, n.id, n.fresh, back)
            is Nav.Alerts -> AlertsUi(c, back)
            is Nav.Prefs -> PrefsUi(c, back)
        }
    }
}
