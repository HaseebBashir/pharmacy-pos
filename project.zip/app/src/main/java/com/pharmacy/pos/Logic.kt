package com.pharmacy.pos

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID

class AppError(message: String) : Exception(message)

data class CartLine(val medicine: Medicine, val qty: Int)

private class Part(val m: Medicine, val b: Batch, val qty: Int, val total: Long)

class Repo(private val db: AppDb) {
    private val dao = db.dao()

    companion object {
        // Price of `qty` base units. Integer math only, rounded half up to the paisa.
        fun lineTotal(m: Medicine, wholesale: Boolean, qty: Int): Long {
            val pack = if (wholesale && m.wholesalePrice > 0) m.wholesalePrice else m.retailPrice
            val ps = maxOf(m.packSize, 1)
            return (pack * qty + ps / 2) / ps
        }
    }

    // Creates the sale, deducts stock (FEFO), writes ledger entries and the invoice number
    // in ONE database transaction. If anything fails nothing is saved.
    suspend fun checkout(
        lines: List<CartLine>,
        customer: Customer?,
        wholesale: Boolean,
        discount: Long,
        paid: Long,
        deviceCode: String
    ): Long = db.withTransaction {
        if (lines.isEmpty()) throw AppError("Cart khali hai")
        val today = Fmt.today()
        val now = System.currentTimeMillis()
        val parts = ArrayList<Part>()
        for (line in lines) {
            val m = dao.medicine(line.medicine.id) ?: throw AppError("Medicine nahi mili")
            val full = Repo.lineTotal(m, wholesale, line.qty)
            val batches = dao.sellableBatches(m.id, today)
            val avail = batches.sumOf { it.qty }
            if (avail < line.qty) {
                throw AppError(m.name + ": sirf " + avail + " maujood (expire ya blocked batch shamil nahi)")
            }
            var need = line.qty
            var allocated = 0L
            for (b in batches) {
                if (need == 0) break
                val take = minOf(need, b.qty)
                need -= take
                val t = if (need == 0) full - allocated else full * take / line.qty
                allocated += t
                parts.add(Part(m, b, take, t))
            }
        }
        val subtotal = parts.sumOf { it.total }
        if (discount < 0 || discount > subtotal) throw AppError("Discount galat hai")
        val total = subtotal - discount
        if (paid < 0) throw AppError("Paid amount galat hai")
        val paidEff = minOf(paid, total)
        val credit = total - paidEff
        if (credit > 0) {
            if (customer == null) throw AppError("Udhaar ke liye customer chunein")
            val bal = dao.balanceOf(customer.id)
            val limit = customer.creditLimit
            if (limit <= 0 || bal + credit > limit) {
                throw AppError("Credit limit se zyada. Limit " + Fmt.rs(limit) + ", baqaya " + Fmt.rs(bal))
            }
        }
        val n = (dao.counter("invoice") ?: 0L) + 1
        dao.setCounter(Counter("invoice", n))
        val inv = deviceCode + "-" + LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE) + "-" +
            n.toString().padStart(6, '0')
        val sale = Sale(
            uuid = UUID.randomUUID().toString(),
            invoiceNo = inv,
            time = now,
            customerId = customer?.id,
            customerName = customer?.name ?: "",
            wholesale = wholesale,
            subtotal = subtotal,
            discount = discount,
            total = total,
            paid = paidEff,
            credit = credit,
            status = "DONE",
            deviceCode = deviceCode
        )
        val saleId = dao.insertSale(sale)
        val items = parts.map {
            SaleItem(
                saleId = saleId, medicineId = it.m.id, batchId = it.b.id, name = it.m.name,
                batchNo = it.b.batchNo, expiryDay = it.b.expiryDay, qty = it.qty,
                packSize = it.m.packSize, lineTotal = it.total
            )
        }
        dao.insertItems(items)
        for (p in parts) {
            val fresh = dao.batch(p.b.id) ?: throw AppError("Batch nahi mila")
            dao.updateBatch(fresh.copy(qty = fresh.qty - p.qty))
            dao.insertMovement(
                StockMovement(time = now, medicineId = p.m.id, batchId = p.b.id, delta = -p.qty, reason = "SALE", ref = inv)
            )
        }
        if (credit > 0 && customer != null) {
            dao.insertLedger(LedgerEntry(customerId = customer.id, time = now, type = "SALE", amount = credit, ref = inv))
        }
        saleId
    }

    suspend fun returnSale(saleId: Long) {
        db.withTransaction {
            val s = dao.sale(saleId) ?: throw AppError("Bill nahi mila")
            if (s.status != "DONE") throw AppError("Ye bill pehle wapas ho chuka hai")
            val now = System.currentTimeMillis()
            for (i in dao.itemsFor(saleId)) {
                val b = dao.batch(i.batchId)
                if (b != null) {
                    dao.updateBatch(b.copy(qty = b.qty + i.qty))
                    dao.insertMovement(
                        StockMovement(time = now, medicineId = i.medicineId, batchId = i.batchId, delta = i.qty, reason = "RETURN", ref = s.invoiceNo)
                    )
                }
            }
            val cid = s.customerId
            if (s.credit > 0 && cid != null) {
                dao.insertLedger(LedgerEntry(customerId = cid, time = now, type = "RETURN", amount = -s.credit, ref = s.invoiceNo))
            }
            dao.updateSale(s.copy(status = "RETURNED"))
        }
    }

    suspend fun receiveStock(medicineId: Long, batchNo: String, expiryDay: Long, qty: Int, costPerPack: Long) {
        db.withTransaction {
            if (qty <= 0) throw AppError("Quantity zero hai")
            if (batchNo.isBlank()) throw AppError("Batch number likhein")
            if (expiryDay < Fmt.today()) throw AppError("Expire batch receive nahi ho sakta")
            val no = batchNo.trim()
            val ex = dao.findBatch(medicineId, no)
            val bid: Long
            if (ex == null) {
                bid = dao.insertBatch(Batch(medicineId = medicineId, batchNo = no, expiryDay = expiryDay, qty = qty, costPerPack = costPerPack))
            } else {
                if (ex.expiryDay != expiryDay) throw AppError("Is batch ka expiry pehle se alag darj hai")
                dao.updateBatch(ex.copy(qty = ex.qty + qty, costPerPack = costPerPack))
                bid = ex.id
            }
            dao.insertMovement(
                StockMovement(time = System.currentTimeMillis(), medicineId = medicineId, batchId = bid, delta = qty, reason = "RECEIVE", ref = no)
            )
        }
    }

    suspend fun setBlocked(batchId: Long, blocked: Boolean) {
        val b = dao.batch(batchId) ?: return
        dao.updateBatch(b.copy(blocked = blocked))
    }

    suspend fun writeOff(batchId: Long) {
        db.withTransaction {
            val b = dao.batch(batchId)
            if (b != null && b.qty > 0) {
                dao.insertMovement(
                    StockMovement(time = System.currentTimeMillis(), medicineId = b.medicineId, batchId = b.id, delta = -b.qty, reason = "WRITEOFF", ref = b.batchNo)
                )
                dao.updateBatch(b.copy(qty = 0))
            }
        }
    }

    suspend fun collectPayment(customerId: Long, amount: Long) {
        if (amount <= 0) throw AppError("Amount galat hai")
        dao.insertLedger(LedgerEntry(customerId = customerId, time = System.currentTimeMillis(), type = "PAYMENT", amount = -amount, ref = "Payment wasool"))
    }
}

data class ShopSettings(
    val shopName: String = "My Pharmacy",
    val shopPhone: String = "",
    val deviceCode: String = "POS-01",
    val printerMac: String = "",
    val printerName: String = "",
    val paper58: Boolean = true
)

class SettingsStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): ShopSettings {
        val d = ShopSettings()
        return ShopSettings(
            shopName = p.getString("shopName", d.shopName) ?: d.shopName,
            shopPhone = p.getString("shopPhone", d.shopPhone) ?: d.shopPhone,
            deviceCode = p.getString("deviceCode", d.deviceCode) ?: d.deviceCode,
            printerMac = p.getString("printerMac", "") ?: "",
            printerName = p.getString("printerName", "") ?: "",
            paper58 = p.getBoolean("paper58", true)
        )
    }

    fun save(s: ShopSettings) {
        p.edit()
            .putString("shopName", s.shopName)
            .putString("shopPhone", s.shopPhone)
            .putString("deviceCode", s.deviceCode)
            .putString("printerMac", s.printerMac)
            .putString("printerName", s.printerName)
            .putBoolean("paper58", s.paper58)
            .apply()
    }
}

object Receipt {
    fun build(st: ShopSettings, sale: Sale, items: List<SaleItem>): String {
        val w = if (st.paper58) 32 else 48
        val sb = StringBuilder()
        fun center(s: String) {
            val t = s.take(w)
            sb.append(" ".repeat((w - t.length) / 2)).append(t).append('\n')
        }
        fun line(l: String, r: String) {
            val space = w - l.length - r.length
            if (space >= 1) {
                sb.append(l).append(" ".repeat(space)).append(r).append('\n')
            } else {
                sb.append(l.take(maxOf(w - r.length - 1, 1))).append(' ').append(r).append('\n')
            }
        }
        fun rule() {
            sb.append("-".repeat(w)).append('\n')
        }
        center(st.shopName)
        if (st.shopPhone.isNotBlank()) center("Tel: " + st.shopPhone)
        rule()
        sb.append("Inv: ").append(sale.invoiceNo).append('\n')
        sb.append("Date: ").append(Fmt.dateTime(sale.time)).append('\n')
        if (sale.customerName.isNotBlank()) sb.append("Customer: ").append(sale.customerName).append('\n')
        if (sale.wholesale) sb.append("Wholesale\n")
        rule()
        for (i in items) {
            sb.append(i.name.take(w)).append('\n')
            line("  " + Fmt.qtyText(i.qty, i.packSize) + " B:" + i.batchNo, Fmt.num(i.lineTotal))
        }
        rule()
        line("Subtotal", Fmt.num(sale.subtotal))
        if (sale.discount > 0) line("Discount", "-" + Fmt.num(sale.discount))
        line("TOTAL (PKR)", Fmt.num(sale.total))
        line("Paid", Fmt.num(sale.paid))
        if (sale.credit > 0) line("Udhaar", Fmt.num(sale.credit))
        rule()
        if (sale.status != "DONE") center("*** BILL WAPAS HO CHUKA ***")
        center("Provisional invoice")
        center("(server sync baqi)")
        center("Shukriya!")
        return sb.toString()
    }
}

object BtPrinter {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private fun adapter(ctx: Context) =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    fun bonded(ctx: Context): List<BluetoothDevice> {
        val ad = adapter(ctx) ?: return emptyList()
        return try {
            ad.bondedDevices.toList()
        } catch (e: SecurityException) {
            emptyList()
        }
    }

    private fun encode(text: String): ByteArray {
        val sb = StringBuilder()
        for (ch in text) {
            if (ch == '\n' || ch.code in 32..126) sb.append(ch) else sb.append('?')
        }
        return sb.toString().toByteArray(Charsets.US_ASCII)
    }

    // Returns null on success, or an error message. A failure here never touches the saved sale.
    suspend fun print(ctx: Context, mac: String, text: String): String? = withContext(Dispatchers.IO) {
        val ad = adapter(ctx)
        if (ad == null) {
            "Is phone mein Bluetooth nahi hai"
        } else if (!ad.isEnabled) {
            "Bluetooth band hai, pehle on karein"
        } else {
            try {
                val dev = ad.getRemoteDevice(mac)
                val sock = dev.createRfcommSocketToServiceRecord(SPP)
                try {
                    ad.cancelDiscovery()
                    sock.connect()
                    val out = sock.outputStream
                    out.write(byteArrayOf(0x1B, 0x40))
                    out.write(encode(text))
                    out.write(byteArrayOf(0x1B, 0x64, 0x04))
                    out.flush()
                    Thread.sleep(600)
                } finally {
                    try {
                        sock.close()
                    } catch (e: Exception) {
                    }
                }
                null
            } catch (e: SecurityException) {
                "Bluetooth ki ijazat nahi mili"
            } catch (e: Exception) {
                "Print nahi hui: " + (e.message ?: "unknown error")
            }
        }
    }
}
