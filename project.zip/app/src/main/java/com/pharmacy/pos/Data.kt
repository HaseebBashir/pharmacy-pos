package com.pharmacy.pos

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

// All money values are stored as Long paisa (Rs 1.00 = 100). All stock quantities are
// stored in base units (loose tablets/pieces). packSize = base units in one pack.

@Entity(tableName = "medicines")
data class Medicine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val brand: String = "",
    val salt: String = "",
    val barcode: String = "",
    val rack: String = "",
    val packSize: Int = 1,
    val retailPrice: Long = 0,
    val wholesalePrice: Long = 0,
    val reorderLevel: Int = 0,
    val active: Boolean = true
)

@Entity(tableName = "batches", indices = [Index("medicineId")])
data class Batch(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val medicineId: Long,
    val batchNo: String,
    val expiryDay: Long,
    val qty: Int,
    val costPerPack: Long = 0,
    val blocked: Boolean = false
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val wholesale: Boolean = false,
    val creditLimit: Long = 0
)

@Entity(tableName = "ledger", indices = [Index("customerId")])
data class LedgerEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val time: Long,
    val type: String,
    val amount: Long,
    val ref: String = ""
)

@Entity(tableName = "sales", indices = [Index(value = ["uuid"], unique = true)])
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uuid: String,
    val invoiceNo: String,
    val time: Long,
    val customerId: Long?,
    val customerName: String,
    val wholesale: Boolean,
    val subtotal: Long,
    val discount: Long,
    val total: Long,
    val paid: Long,
    val credit: Long,
    val status: String,
    val deviceCode: String
)

@Entity(tableName = "sale_items", indices = [Index("saleId")])
data class SaleItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val medicineId: Long,
    val batchId: Long,
    val name: String,
    val batchNo: String,
    val expiryDay: Long,
    val qty: Int,
    val packSize: Int,
    val lineTotal: Long
)

@Entity(tableName = "stock_movements")
data class StockMovement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long,
    val medicineId: Long,
    val batchId: Long,
    val delta: Int,
    val reason: String,
    val ref: String = ""
)

@Entity(tableName = "counters")
data class Counter(
    @PrimaryKey val name: String,
    val value: Long
)

data class StockRow(val medicineId: Long, val total: Int)
data class BalanceRow(val customerId: Long, val total: Long)

@Dao
interface PharmaDao {
    @Query("SELECT * FROM medicines WHERE active = 1 AND (:q = '' OR name LIKE '%' || :q || '%' OR brand LIKE '%' || :q || '%' OR salt LIKE '%' || :q || '%' OR barcode = :q) ORDER BY name LIMIT 200")
    fun searchMedicines(q: String): Flow<List<Medicine>>

    @Query("SELECT * FROM medicines WHERE active = 1 ORDER BY name")
    fun allMedicines(): Flow<List<Medicine>>

    @Query("SELECT * FROM medicines WHERE id = :id")
    suspend fun medicine(id: Long): Medicine?

    @Query("SELECT * FROM medicines WHERE barcode = :code AND barcode != '' LIMIT 1")
    suspend fun medicineByBarcode(code: String): Medicine?

    @Insert
    suspend fun insertMedicine(m: Medicine): Long

    @Update
    suspend fun updateMedicine(m: Medicine)

    @Query("SELECT * FROM batches WHERE medicineId = :id ORDER BY expiryDay")
    fun batchesFor(id: Long): Flow<List<Batch>>

    @Query("SELECT * FROM batches WHERE medicineId = :id AND qty > 0 AND blocked = 0 AND expiryDay >= :today ORDER BY expiryDay, id")
    suspend fun sellableBatches(id: Long, today: Long): List<Batch>

    @Query("SELECT * FROM batches WHERE id = :id")
    suspend fun batch(id: Long): Batch?

    @Query("SELECT * FROM batches WHERE medicineId = :mid AND batchNo = :no LIMIT 1")
    suspend fun findBatch(mid: Long, no: String): Batch?

    @Insert
    suspend fun insertBatch(b: Batch): Long

    @Update
    suspend fun updateBatch(b: Batch)

    @Query("SELECT medicineId, COALESCE(SUM(qty), 0) AS total FROM batches WHERE blocked = 0 AND expiryDay >= :today GROUP BY medicineId")
    fun stockTotals(today: Long): Flow<List<StockRow>>

    @Query("SELECT * FROM batches WHERE qty > 0 AND expiryDay <= :limit ORDER BY expiryDay")
    fun expiringBatches(limit: Long): Flow<List<Batch>>

    @Query("SELECT * FROM customers ORDER BY name")
    fun customers(): Flow<List<Customer>>

    @Query("SELECT * FROM customers WHERE id = :id")
    suspend fun customer(id: Long): Customer?

    @Insert
    suspend fun insertCustomer(c: Customer): Long

    @Update
    suspend fun updateCustomer(c: Customer)

    @Query("SELECT customerId, COALESCE(SUM(amount), 0) AS total FROM ledger GROUP BY customerId")
    fun balances(): Flow<List<BalanceRow>>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM ledger WHERE customerId = :id")
    suspend fun balanceOf(id: Long): Long

    @Query("SELECT * FROM ledger WHERE customerId = :id ORDER BY id DESC")
    fun ledgerFor(id: Long): Flow<List<LedgerEntry>>

    @Insert
    suspend fun insertLedger(e: LedgerEntry): Long

    @Insert
    suspend fun insertSale(s: Sale): Long

    @Insert
    suspend fun insertItems(items: List<SaleItem>)

    @Update
    suspend fun updateSale(s: Sale)

    @Query("SELECT * FROM sales WHERE id = :id")
    suspend fun sale(id: Long): Sale?

    @Query("SELECT * FROM sale_items WHERE saleId = :id ORDER BY id")
    suspend fun itemsFor(id: Long): List<SaleItem>

    @Query("SELECT * FROM sales ORDER BY id DESC LIMIT 300")
    fun recentSales(): Flow<List<Sale>>

    @Query("SELECT COALESCE(SUM(total), 0) FROM sales WHERE time >= :from AND status = 'DONE'")
    fun salesTotalSince(from: Long): Flow<Long>

    @Query("SELECT COUNT(*) FROM sales WHERE time >= :from AND status = 'DONE'")
    fun salesCountSince(from: Long): Flow<Int>

    @Insert
    suspend fun insertMovement(m: StockMovement)

    @Query("SELECT value FROM counters WHERE name = :k")
    suspend fun counter(k: String): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setCounter(c: Counter)
}

@Database(
    entities = [Medicine::class, Batch::class, Customer::class, LedgerEntry::class, Sale::class,
        SaleItem::class, StockMovement::class, Counter::class],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): PharmaDao

    companion object {
        @Volatile
        private var inst: AppDb? = null

        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "pharmacy.db")
                .build().also { inst = it }
        }
    }
}
